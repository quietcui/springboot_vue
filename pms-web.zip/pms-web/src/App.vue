<script>

</script>
<template>
  <div id="app">
    <router-view/>
  </div>
</template>



<style>
#app {
  height: 100%;
  width: 100%;
}
</style>
